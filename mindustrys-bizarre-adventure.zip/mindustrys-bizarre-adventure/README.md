![Logo](icon.png)

Mindustry's Bizarre Adventure. I Chose To Make This Mod Because So Far No One Has Made A Mod Based Off Of A Cool Anime Series Called "JoJo's Bizarre Adventure". The Mod Focuses On Making Turrets And Other Blocks Based And Referenced Off Of The Anime Series. 
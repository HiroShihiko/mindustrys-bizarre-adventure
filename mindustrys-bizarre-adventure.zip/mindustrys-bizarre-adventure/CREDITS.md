Some Of These Contents Arent Mine, Nor Did I Do This Alone. I Had A Few Helpers Who Thought Me And Helped Me Code. Thank You So Much For Those Who Helped, It Means Alot To Me.

Mods Used:
Advance Content Mod
Mindustry Plus Mod
Anuken's Example Mod
AddTurret Mod

Special Thanks To:
[FGP] XYX.Ph
NightRaven (JheCabs)
Niirk
GlennFolker
Zen
Jamie
Green
And Many...many More.

Thank You So Very Much. 




                               —Hiro_Shihiko <3